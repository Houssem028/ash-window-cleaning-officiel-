// Firebase config
console.log('Firebase JS')